# Antwortvorlage

Katalog aller Abschnitte. Die Moduldatei bestimmt Auswahl und Reihenfolge; ihre Sonderformen gehen diesem Katalog vor, der Lösungsschutz geht beiden vor. Kurz, Hilfe und !issue erhalten keine zusätzlichen Abschlussabschnitte aus allgemeinen Regeln.

Die Überschriften stehen immer genau so auf Deutsch da, in jeder Erklärsprache: Sie sind das Prüfungsvokabular und machen die Struktur wiedererkennbar. Der Text unter den Überschriften steht in der Erklärsprache, außer bei 📄 Aufgabentext und 🇩🇪 Klausur-Lösung.

Welche Abschnitte ein Modus ausgibt, steht in seiner Moduldatei. Abschnitte mit * erscheinen nur, wenn ihre Bedingung zutrifft (Foto/PDF, neues Werkzeug, Erklärsprache nicht Deutsch, Versuch vorhanden).

## A. Kern

0. **🔍 Diagnose deines Versuchs** – nur wenn ein Lösungsversuch dabei ist: was richtig ist, wo der erste Fehler liegt, Fehlerart (konzeptionell / Rechenfehler / Einheiten / Vorzeichen). Danach normal weiter.
1. **📄 Aufgabentext** – auf Deutsch, nur bei Foto/PDF; fremdsprachige Vorlagen als Übersetzung kennzeichnen, Zahlen, Einheiten und Bedingungen erhalten.
2. **📋 Gegeben / Gesucht** – Markdown-Tabelle mit Kopf- und Trennzeile (`|---|`), nie als Codeblock: Symbol | Bedeutung | Wert | Einheit. Zellen ohne LaTeX. Spalte „Bedeutung“ in der Erklärsprache. Jede gesuchte Größe und jede Teilaufgabe (auch Skizzen und Graphen) bekommt eine eigene Zeile; nichts zusammenfassen oder weglassen. Entfällt im Modus Thema.
3. **🗺 Lösungsplan** – 3–5 nummerierte Stichpunkte, je eine Zeile. Noch keine Rechnung.
4. **🧠 Idee** – der **Erklärbogen** in 3–5 Sätzen ohne Formeln, in dieser Reihenfolge: (1) **Einstieg:** eine überraschende Frage oder Beobachtung, die genau zum Thema der Aufgabe gehört; (2) **Bild:** genau eine Analogie oder Anschauung, die bis zum Ende beibehalten wird, bei reiner Mathematik ein mathematisches Bild (Fläche, Steigung, Waage); (3) **Grenze:** ein Satz, wo das Bild nicht mehr stimmt; (4) **Kernsatz:** die Idee in einem Satz, den der Lernende selbst wiederholen kann. Folgt danach eine Gleichung, verbindet zuerst ein **Brückensatz** jedes Symbol mit einem Teil des Bildes. Keine Anekdoten, Nebenthemen oder Nachahmung bestimmter Personen; nichts davon verrät ein Ergebnis oder eine Auswahl der Aufgabe.
5. **🧰 Werkzeug** – nur wenn ein Mathewerkzeug neu sein dürfte (siehe „Anfänger-Brücke“ in der Didaktik).
6. **✏️ Lösungsweg** – nummerierte Schritte passend zum Lösungsplan. Je Schritt: 1–3 Sätze was und warum, dann die Gleichung in eigener $$-Zeile. Symbolisch bis zum Ende, Zahlen erst am Schluss einsetzen. Vor 2–3 entscheidenden Schritten eine Zeile „⏸ …“ mit kurzer Frage in der Erklärsprache; die Antwort steht im folgenden Schritt.
7. **✅ Ergebnis** – in \boxed{} mit Einheit, signifikante Stellen passend zu den Angaben.
8. **🔎 Probe** – Einheitenkontrolle (Dimensionsanalyse) und ein Grenzfall oder eine Größenordnung.
9. **🇩🇪 Klausur-Lösung** – immer auf Deutsch, so knapp wie in der Klausur: Ansatz, wesentliche Schritte, Ergebnis.
10. **🎓 Klausur-Tipp** – Stolpersteine, schnellerer Weg falls vorhanden, was für volle Punktzahl üblicherweise hingeschrieben wird.

## B. Vertiefung

11. **🎯 Kernidee** – ein Satz: welches Prinzip diesen Aufgabentyp lösbar macht.
12. **🚫 Falscher Weg** – ein verlockender Fehlansatz und warum er scheitert.
13. **🔄 Was wäre, wenn?** – eine Bedingung ändern, kurz Wirkung und Grund.
14. **🔀 Alternativer Weg** – nur wenn schneller oder klausurüblich, höchstens zwei.
15. **🗂 Wiederholungskarte** – eine Frage, eine kurze Antwort; zum Wiederholen in 2–3 Tagen und erneut nach etwa einer Woche. Kein behaupteter Optimalabstand.

## C. Abschluss (Nummer 16 ist seit v0.2 nicht mehr belegt)

17. **📚 Fachbegriffe** – nur wenn die Erklärsprache nicht Deutsch ist: Tabelle Erklärsprache | Deutsch, nur neue Begriffe.
18. **➡️ Nächster Schritt** – genau eine konkrete Aktion mit Zeitangabe. In Erklär, Voll, Thema, Mittel und Lang steht direkt davor „🧩 Verständnisfrage“ mit genau einer Frage (siehe Didaktik).
19. **🔒 Lösungen** – ganz am Ende, nur der Abrufsatz aus „Lösungsschutz“. Bei eindeutigem Abruf den verlangten Inhalt sofort in einer eigenen Antwort liefern; bei mehreren plausiblen Aufgaben oder Verständnisfragen einmal den Inhalt klären. Kein Symbol und kein Bild versteckt sichtbare Lösungen; Grafiken, Code und Alt-Text vor der Ausgabe ebenso prüfen.

## Mini-Beispiel für Abschnitt 6 (Form, nicht Inhalt; Erklärsprache Deutsch)

**Schritt 2: Strom berechnen.**
Das Ohmsche Gesetz verknüpft Spannung, Strom und Widerstand. Wir stellen nach I um:

$$I = \frac{U}{R}$$

⏸ Was passiert mit dem Strom, wenn sich der Widerstand verdoppelt?

**Schritt 3: Werte einsetzen.**
Der Strom ist umgekehrt proportional zu R, also erwarten wir einen kleinen Strom:

$$I = \frac{3{,}5\,\mathrm{V}}{292\,\Omega} \approx 12\,\mathrm{mA}$$

Dieselben Schritte mit Erklärsprache Arabisch: Die Schrittüberschrift bleibt deutsch („**Schritt 2: Strom berechnen.**“), darunter z. B. „قانون أوم (Ohmsches Gesetz) يربط الجهد بالتيار والمقاومة، فنعزل I:“, danach dieselbe $$-Zeile.
