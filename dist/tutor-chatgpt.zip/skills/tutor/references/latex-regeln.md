# LaTeX- und Formatregeln

Diese Regeln stammen aus echten Darstellungsfehlern in der Claude-App und in ChatGPT bei arabischem Text. Sie gelten für jede Antwort dieses Skills.

## Warum
- `\[ ... \]` und `\( ... \)` werden in der Claude-App nicht zuverlässig gerendert: Der Backslash geht verloren, übrig bleiben `[`, `]` und roher Code.
- Inline-Formeln in arabischen und Urdu-Sätzen werden durch die Rechts-nach-links-Richtung umsortiert; Vorzeichen landen auf der falschen Seite.
- Nicht-ASCII-Zeichen wie ß in `\text{}` oder `\mathrm{}` lassen den Renderer scheitern. Das betrifft jede Erklärsprache (Arabisch, Türkisch, Französisch, Englisch, Urdu, Deutsch).

## Regeln
1. Jede Formel steht zwischen `$$ ... $$` in einer eigenen Zeile, mit Leerzeile davor und danach.
2. Niemals `\[ \]`, `\( \)` oder einfaches `$` verwenden.
3. Im Fließtext kein LaTeX. Einzelne Symbole als normale lateinische Buchstaben schreiben (x, U0, R). Alles mit +, −, = oder einem Bruch kommt in eine eigene $$-Zeile.
4. In LaTeX nur ASCII: keine arabischen Buchstaben (auch nicht aus Urdu), kein ß ä ö ü, kein ç ğ ı ş, kein é è à, keine ganzen Wörter in irgendeiner Sprache. Text-Indizes als kurzer lateinischer Buchstabe: A_\mathrm{w}; die Bedeutung im Text erklären („A_w: Fläche der weißen Dreiecke“).
5. Brüche immer mit vollen Klammern: \frac{1}{2}, nie \frac12. Klammern immer ausgeglichen.
6. Endergebnis: \boxed{...} innerhalb von $$ ... $$.
7. SI-Schreibweise: Einheit aufrecht mit \mathrm{}, kleines Leerzeichen \, zwischen Zahlenwert und Einheit, Dezimalkomma als {,}. Ausnahme: Winkelgrad, Winkelminute und Winkelsekunde direkt an den Zahlenwert (z. B. 30^{\circ}); Grad Celsius dagegen mit Abstand (z. B. 20\,{}^{\circ}\mathrm{C}). Grundlage: BIPM-SI-Broschüre, Kapitel 5; daraus keine vollständige DIN-/ISO-Konformität ableiten.
8. Tabellen enthalten kein LaTeX, nur reinen Text: U0 | 3,5 | V.
9. Meldet der Lernende sichtbares `$$`, Backslashes oder Rohcode, rendert die Oberfläche kein LaTeX: ab dann jede Formel als lesbarer Unicode-Klartext in eigener Zeile (E_kin = ½ · m · v², F_R = μ · F_N, Δx = 15 m), ohne `$$`. Nicht behaupten, Formeln würden gesetzt, ohne es zu sehen.
10. Formelzeichen beim ersten Auftreten mit Bedeutung und Einheit nennen (F_R: Reibungskraft in N, μ: Gleitreibungszahl, dimensionslos). Größenzeichen einschließlich physikalischer Konstanten (z. B. c, g, h) kursiv, Einheiten und beschreibende Indizes aufrecht. Mathematische Konstanten und Operatoren von Größen unterscheiden: e als Basis der Exponentialfunktion nicht mit einer physikalischen Größe e verwechseln. Für pi den üblichen Befehl \pi verwenden; keine nicht unterstützten Aufrecht-Befehle erzwingen. Ein Kurspaket geht bei der Notation vor; keine ungeprüfte Schreibweise als einzig normgerecht bezeichnen.

## Richtig

$$U = 3{,}5\,\mathrm{V}, \qquad R = \frac{U}{I} \approx 292\,\Omega$$

$$A_\mathrm{w} = 2 \cdot \frac{1}{2}\, y^2 = y^2$$

## Falsch (so ist es kaputtgegangen)

- `\[ A_\mathrm{weiß} = 2 \cdot \frac{1}{2} y^2 \]` → Klammern sichtbar, ß bricht ab.
- `كل مثلث مساحته \(\frac{1}{2}y^2\)` → Rohcode im Satz.
- `يختزل الحدّان +2xy و −2xy` mit Inline-Formel → Vorzeichen vertauscht. Stattdessen:

$$+2xy - 2xy = 0$$

## Letzter Check vor dem Senden
- Kein `\[`, `\(` oder einzelnes `$` im Text?
- Kein ß ä ö ü oder arabisches Zeichen zwischen `$$`?
- Jede `$$`-Zeile hat ausgeglichene Klammern?
- Wurde Rohcode gemeldet: Klartextformeln statt `$$`?
