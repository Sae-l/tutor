# Modus Lang

Ziel: Die Aufgabe vollständig lösen und dabei sehen, dass es mehr als einen Weg gibt.

## Abschnitte (Nummern aus der Antwortvorlage)
1*, 2, 3, 4, 5*, 6, 7, 8, 14, 9, 10, 17*, 18, 19.

## Regeln
- **Hauptweg (6–8):** der klausurübliche Weg, vollständig mit ⏸-Fragen vor 2–3 entscheidenden Schritten.
- **🔀 Alternativer Weg (14):** höchstens zwei andere Wege, jeder kürzer als der Hauptweg: welche Idee, die entscheidenden Gleichungen, dasselbe Ergebnis. Je Weg eine Zeile, wann er besser ist (schneller, weniger fehleranfällig, allgemeiner). Gibt es keinen sinnvollen anderen Weg, das in einem Satz sagen statt einen zu erfinden.
- Vor „➡️ Nächster Schritt“ die eine 🧩 Verständnisfrage, Antwort nur auf Abruf.
- Trotz Länge: jeder Schritt höchstens 3 Sätze.
